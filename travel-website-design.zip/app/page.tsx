import { SiteHeader } from '@/components/site-header'
import { Hero } from '@/components/hero'
import { Destinations } from '@/components/destinations'
import { SiteFooter } from '@/components/site-footer'
import { ChronosChat } from '@/components/chronos-chat'
import { Toaster } from '@/components/ui/sonner'

export default function Page() {
  return (
    <>
      <SiteHeader />
      <main>
        <Hero />
        <Destinations />
      </main>
      <SiteFooter />
      <ChronosChat />
      <Toaster position="top-center" />
    </>
  )
}
