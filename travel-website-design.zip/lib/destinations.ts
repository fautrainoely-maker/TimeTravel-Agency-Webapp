export type Destination = {
  id: string
  era: string
  title: string
  location: string
  year: string
  image: string
  tagline: string
  description: string
  highlights: string[]
  duration: string
  price: string
  risk: 'Faible' | 'Modéré' | 'Élevé'
}

export const destinations: Destination[] = [
  {
    id: 'paris-1889',
    era: 'Belle Époque',
    title: 'Paris 1889',
    location: 'Paris, France',
    year: '1889',
    image: '/destinations/paris-1889.png',
    tagline: "L'Exposition Universelle dans toute sa splendeur",
    description:
      "Assistez à l'inauguration de la Tour Eiffel encore couverte d'échafaudages dorés. Déambulez sous les lumières au gaz de la Belle Époque, entre dirigeables de cuivre et pavillons d'un monde émerveillé par le progrès.",
    highlights: [
      "Inauguration de la Tour Eiffel",
      'Dîner Belle Époque au Champ-de-Mars',
      'Vol en montgolfière au-dessus de Paris',
    ],
    duration: '3 jours subjectifs',
    price: '12 900 €',
    risk: 'Faible',
  },
  {
    id: 'cretace',
    era: 'Mésozoïque',
    title: 'Le Crétacé',
    location: 'Pangée tardive',
    year: '−72 millions',
    image: '/destinations/cretace.png',
    tagline: 'Marchez parmi les géants, à distance raisonnable',
    description:
      "Une jungle primordiale grouillante de vie, des fougères géantes aux volcans grondants. Observez sauropodes et ptérosaures depuis une plateforme d'observation blindée, sous l'œil vigilant de nos guides chrono-naturalistes.",
    highlights: [
      'Safari blindé parmi les sauropodes',
      "Observation de ptérosaures à l'aube",
      'Nuit sous un ciel sans pollution lumineuse',
    ],
    duration: '5 jours subjectifs',
    price: '24 500 €',
    risk: 'Élevé',
  },
  {
    id: 'florence-1504',
    era: 'Renaissance',
    title: 'Florence 1504',
    location: 'Florence, Italie',
    year: '1504',
    image: '/destinations/florence-1504.png',
    tagline: "L'âge d'or des maîtres au coucher du soleil",
    description:
      "Franchissez les ruelles toscanes à l'heure dorée, sous le Duomo et les toits de terre cuite. Visitez les ateliers où le marbre prend vie et croisez le regard des plus grands esprits de la Renaissance.",
    highlights: [
      "Visite privée d'un atelier de sculpture",
      'Dîner toscan sur les rives de l’Arno',
      'Vue exclusive sur le dévoilement du David',
    ],
    duration: '4 jours subjectifs',
    price: '18 200 €',
    risk: 'Modéré',
  },
]
