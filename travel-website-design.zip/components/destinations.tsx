'use client'

import { useState } from 'react'
import { destinations, type Destination } from '@/lib/destinations'
import { Button } from '@/components/ui/button'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { BookingForm } from '@/components/booking-form'
import { ArrowUpRight, Check, Clock, MapPin, ShieldAlert } from 'lucide-react'
import { cn } from '@/lib/utils'

const riskStyles: Record<Destination['risk'], string> = {
  Faible: 'text-chart-4 border-chart-4/40',
  Modéré: 'text-primary border-primary/40',
  Élevé: 'text-accent border-accent/50',
}

function DestinationCard({
  destination,
  onSelect,
}: {
  destination: Destination
  onSelect: () => void
}) {
  return (
    <button
      onClick={onSelect}
      className="group relative flex flex-col overflow-hidden rounded-2xl border border-border bg-card text-left transition-all duration-300 hover:-translate-y-1 hover:border-primary/50"
    >
      <div className="relative aspect-[4/5] overflow-hidden">
        <img
          src={destination.image || '/placeholder.svg'}
          alt={`${destination.title} — ${destination.tagline}`}
          className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-card via-card/30 to-transparent" />
        <span className="absolute left-4 top-4 rounded-full border border-primary/30 bg-background/60 px-3 py-1 font-mono text-xs uppercase tracking-widest text-primary backdrop-blur-sm">
          {destination.era}
        </span>
        <span className="absolute right-4 top-4 font-mono text-xs text-foreground/70">
          {destination.year}
        </span>
      </div>

      <div className="flex flex-1 flex-col p-6">
        <h3 className="font-heading text-2xl font-semibold text-foreground">
          {destination.title}
        </h3>
        <p className="mt-1 flex items-center gap-1.5 text-sm text-muted-foreground">
          <MapPin className="size-3.5" /> {destination.location}
        </p>
        <p className="mt-3 text-pretty text-sm leading-relaxed text-muted-foreground">
          {destination.tagline}
        </p>
        <div className="mt-6 flex items-center justify-between border-t border-border pt-4">
          <span className="font-heading text-lg font-semibold text-primary">
            {destination.price}
          </span>
          <span className="inline-flex items-center gap-1 text-sm font-medium text-foreground transition-colors group-hover:text-primary">
            Explorer
            <ArrowUpRight className="size-4 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
          </span>
        </div>
      </div>
    </button>
  )
}

export function Destinations() {
  const [selected, setSelected] = useState<Destination | null>(null)

  return (
    <section id="destinations" className="relative scroll-mt-16 py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-2xl text-center">
          <p className="font-mono text-xs uppercase tracking-[0.3em] text-primary">
            Trois époques · Une seule porte
          </p>
          <h2 className="mt-4 font-heading text-4xl font-semibold text-balance text-foreground sm:text-5xl">
            Choisissez votre destination
          </h2>
          <p className="mt-4 text-pretty leading-relaxed text-muted-foreground">
            Chaque expédition est encadrée par nos chrono-guides certifiés. Sélectionnez une
            époque pour découvrir le programme et réserver votre départ.
          </p>
        </div>

        <div className="mt-16 grid gap-6 md:grid-cols-3">
          {destinations.map((destination) => (
            <DestinationCard
              key={destination.id}
              destination={destination}
              onSelect={() => setSelected(destination)}
            />
          ))}
        </div>
      </div>

      <Dialog open={!!selected} onOpenChange={(o) => !o && setSelected(null)}>
        <DialogContent className="max-h-[90vh] gap-0 overflow-y-auto p-0 sm:max-w-2xl">
          {selected && (
            <>
              <div className="relative h-44 w-full overflow-hidden">
                <img
                  src={selected.image || '/placeholder.svg'}
                  alt={selected.title}
                  className="h-full w-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-popover to-transparent" />
                <span className="absolute bottom-3 left-5 font-mono text-xs uppercase tracking-widest text-primary">
                  {selected.era} · {selected.year}
                </span>
              </div>

              <div className="grid gap-6 p-6 md:grid-cols-2">
                <div>
                  <DialogHeader>
                    <DialogTitle className="font-heading text-2xl">{selected.title}</DialogTitle>
                    <DialogDescription className="text-sm">
                      {selected.description}
                    </DialogDescription>
                  </DialogHeader>

                  <div className="mt-5 flex flex-wrap gap-2 text-xs">
                    <span className="inline-flex items-center gap-1.5 rounded-full border border-border px-3 py-1 text-muted-foreground">
                      <Clock className="size-3.5" /> {selected.duration}
                    </span>
                    <span
                      className={cn(
                        'inline-flex items-center gap-1.5 rounded-full border px-3 py-1',
                        riskStyles[selected.risk],
                      )}
                    >
                      <ShieldAlert className="size-3.5" /> Paradoxe : {selected.risk}
                    </span>
                  </div>

                  <ul className="mt-5 grid gap-2.5">
                    {selected.highlights.map((h) => (
                      <li key={h} className="flex items-start gap-2 text-sm text-foreground">
                        <Check className="mt-0.5 size-4 shrink-0 text-primary" />
                        <span>{h}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="rounded-xl border border-border bg-secondary/30 p-5">
                  <h4 className="mb-4 font-heading text-lg font-semibold text-foreground">
                    Réservation rapide
                  </h4>
                  <BookingForm destination={selected} onComplete={() => setSelected(null)} />
                </div>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </section>
  )
}
