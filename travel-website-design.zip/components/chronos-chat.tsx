'use client'

import { useChat } from '@ai-sdk/react'
import { DefaultChatTransport } from 'ai'
import { useEffect, useRef, useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { cn } from '@/lib/utils'
import { Hourglass, Send, X } from 'lucide-react'

const SUGGESTIONS = [
  'Quelle époque me conseilles-tu ?',
  'Le Crétacé est-il dangereux ?',
  'Comment se déroule un voyage ?',
]

export function ChronosChat() {
  const [open, setOpen] = useState(false)
  const [input, setInput] = useState('')
  const scrollRef = useRef<HTMLDivElement>(null)

  const { messages, sendMessage, status, error } = useChat({
    transport: new DefaultChatTransport({ api: '/api/chat' }),
  })

  useEffect(() => {
    const handler = () => setOpen(true)
    window.addEventListener('open-chronos', handler)
    return () => window.removeEventListener('open-chronos', handler)
  }, [])

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' })
  }, [messages, status])

  const busy = status === 'submitted' || status === 'streaming'

  const submit = (text: string) => {
    if (!text.trim() || busy) return
    sendMessage({ text })
    setInput('')
  }

  return (
    <div id="chronos" className="fixed bottom-5 right-5 z-50 flex flex-col items-end">
      {/* Panel */}
      <div
        className={cn(
          'mb-3 flex w-[calc(100vw-2.5rem)] max-w-sm origin-bottom-right flex-col overflow-hidden rounded-2xl border border-border bg-popover shadow-2xl shadow-black/40 transition-all duration-300',
          open
            ? 'pointer-events-auto translate-y-0 scale-100 opacity-100'
            : 'pointer-events-none translate-y-4 scale-95 opacity-0',
        )}
        style={{ height: open ? 'min(32rem, 70vh)' : 0 }}
        aria-hidden={!open}
      >
        {/* Header */}
        <div className="flex items-center justify-between border-b border-border bg-card/60 px-4 py-3">
          <div className="flex items-center gap-2.5">
            <span className="relative flex size-9 items-center justify-center rounded-full border border-primary/40 text-primary">
              <Hourglass className="size-4" />
              <span className="absolute -bottom-0.5 -right-0.5 size-2.5 rounded-full border-2 border-popover bg-chart-4" />
            </span>
            <div>
              <p className="font-heading text-sm font-semibold leading-tight text-foreground">
                Chronos
              </p>
              <p className="text-xs text-muted-foreground">Concierge temporel · En ligne</p>
            </div>
          </div>
          <Button variant="ghost" size="icon-sm" aria-label="Fermer" onClick={() => setOpen(false)}>
            <X className="size-4" />
          </Button>
        </div>

        {/* Messages */}
        <div ref={scrollRef} className="flex-1 space-y-4 overflow-y-auto px-4 py-4">
          {messages.length === 0 && (
            <div className="space-y-4">
              <div className="rounded-2xl rounded-tl-sm bg-secondary px-4 py-3 text-sm leading-relaxed text-secondary-foreground">
                Bonjour, voyageur. Je suis <span className="text-primary">Chronos</span>, votre
                concierge à travers les âges. Où le temps vous appelle-t-il aujourd&apos;hui ?
              </div>
              <div className="flex flex-wrap gap-2">
                {SUGGESTIONS.map((s) => (
                  <button
                    key={s}
                    onClick={() => submit(s)}
                    className="rounded-full border border-border px-3 py-1.5 text-xs text-muted-foreground transition-colors hover:border-primary/50 hover:text-foreground"
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>
          )}

          {messages.map((message) => (
            <div
              key={message.id}
              className={cn('flex', message.role === 'user' ? 'justify-end' : 'justify-start')}
            >
              <div
                className={cn(
                  'max-w-[85%] whitespace-pre-wrap rounded-2xl px-4 py-2.5 text-sm leading-relaxed',
                  message.role === 'user'
                    ? 'rounded-br-sm bg-primary text-primary-foreground'
                    : 'rounded-tl-sm bg-secondary text-secondary-foreground',
                )}
              >
                {message.parts.map((part, i) =>
                  part.type === 'text' ? <span key={i}>{part.text}</span> : null,
                )}
              </div>
            </div>
          ))}

          {status === 'submitted' && (
            <div className="flex justify-start">
              <div className="flex gap-1 rounded-2xl rounded-tl-sm bg-secondary px-4 py-3">
                <span className="size-1.5 animate-bounce rounded-full bg-muted-foreground [animation-delay:-0.3s]" />
                <span className="size-1.5 animate-bounce rounded-full bg-muted-foreground [animation-delay:-0.15s]" />
                <span className="size-1.5 animate-bounce rounded-full bg-muted-foreground" />
              </div>
            </div>
          )}

          {error && (
            <div className="flex justify-start">
              <div className="max-w-[85%] rounded-2xl rounded-tl-sm border border-accent/40 bg-accent/10 px-4 py-2.5 text-sm leading-relaxed text-foreground">
                Une interférence temporelle m&apos;empêche de répondre pour l&apos;instant. Le flux
                Chronos est momentanément indisponible — réessayez dans un instant.
              </div>
            </div>
          )}
        </div>

        {/* Composer */}
        <form
          onSubmit={(e) => {
            e.preventDefault()
            submit(input)
          }}
          className="flex items-center gap-2 border-t border-border bg-card/60 p-3"
        >
          <Input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.nativeEvent.isComposing && e.keyCode !== 229) {
                e.preventDefault()
                submit(input)
              }
            }}
            placeholder="Écrivez à Chronos…"
            className="flex-1"
            disabled={busy}
          />
          <Button type="submit" size="icon" aria-label="Envoyer" disabled={busy || !input.trim()}>
            <Send className="size-4" />
          </Button>
        </form>
      </div>

      {/* Floating launcher */}
      <button
        onClick={() => setOpen((v) => !v)}
        aria-label={open ? 'Réduire Chronos' : 'Ouvrir Chronos'}
        className="group flex items-center gap-2.5 rounded-full border border-primary/40 bg-card px-4 py-3 shadow-xl shadow-black/30 transition-all hover:border-primary hover:shadow-primary/10"
      >
        <span className="relative flex size-7 items-center justify-center rounded-full bg-primary text-primary-foreground">
          {open ? <X className="size-4" /> : <Hourglass className="size-4" />}
        </span>
        <span className="pr-1 font-heading text-sm font-semibold text-foreground">
          {open ? 'Fermer' : 'Chronos'}
        </span>
      </button>
    </div>
  )
}
