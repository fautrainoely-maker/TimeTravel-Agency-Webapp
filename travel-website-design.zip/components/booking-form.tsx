'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { toast } from 'sonner'
import type { Destination } from '@/lib/destinations'
import { Loader2 } from 'lucide-react'

export function BookingForm({
  destination,
  onComplete,
}: {
  destination: Destination
  onComplete?: () => void
}) {
  const [loading, setLoading] = useState(false)

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    const form = e.currentTarget
    const name = (form.elements.namedItem('name') as HTMLInputElement).value
    setLoading(true)
    // Simulate dispatching the chrono-booking
    setTimeout(() => {
      setLoading(false)
      toast.success('Expédition réservée', {
        description: `${name}, votre départ pour ${destination.title} est confirmé. Un chrono-concierge vous contactera dans cette ligne temporelle.`,
      })
      onComplete?.()
    }, 1100)
  }

  return (
    <form onSubmit={handleSubmit} className="grid gap-4">
      <div className="grid gap-2">
        <Label htmlFor="name">Nom du voyageur</Label>
        <Input id="name" name="name" required placeholder="Ada Lovelace" autoComplete="name" />
      </div>
      <div className="grid gap-2">
        <Label htmlFor="email">Adresse (présent)</Label>
        <Input
          id="email"
          name="email"
          type="email"
          required
          placeholder="vous@exemple.fr"
          autoComplete="email"
        />
      </div>
      <div className="grid grid-cols-2 gap-4">
        <div className="grid gap-2">
          <Label htmlFor="date">Date de départ</Label>
          <Input id="date" name="date" type="date" required />
        </div>
        <div className="grid gap-2">
          <Label htmlFor="travelers">Voyageurs</Label>
          <Input
            id="travelers"
            name="travelers"
            type="number"
            min={1}
            max={6}
            defaultValue={1}
            required
          />
        </div>
      </div>

      <div className="mt-1 flex items-center justify-between rounded-lg border border-border bg-secondary/40 px-4 py-3">
        <span className="text-sm text-muted-foreground">À partir de</span>
        <span className="font-heading text-xl font-semibold text-primary">{destination.price}</span>
      </div>

      <Button type="submit" size="lg" disabled={loading} className="mt-1 w-full">
        {loading ? (
          <>
            <Loader2 className="size-4 animate-spin" /> Calibrage temporel…
          </>
        ) : (
          'Confirmer la réservation'
        )}
      </Button>
      <p className="text-center text-xs text-muted-foreground">
        En réservant, vous acceptez la Clause de non-responsabilité des paradoxes.
      </p>
    </form>
  )
}
