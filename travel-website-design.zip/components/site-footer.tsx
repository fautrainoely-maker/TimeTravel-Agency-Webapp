import { Hourglass } from 'lucide-react'

export function SiteFooter() {
  return (
    <footer className="border-t border-border bg-card/40">
      <div className="mx-auto max-w-7xl px-4 py-14 sm:px-6 lg:px-8">
        <div className="flex flex-col gap-10 md:flex-row md:justify-between">
          <div className="max-w-sm">
            <div className="flex items-center gap-2">
              <span className="flex size-8 items-center justify-center rounded-full border border-primary/40 text-primary">
                <Hourglass className="size-4" aria-hidden="true" />
              </span>
              <span className="font-heading text-lg font-semibold text-foreground">
                Chrono<span className="text-primary">-Voyages</span>
              </span>
            </div>
            <p className="mt-4 text-sm leading-relaxed text-muted-foreground">
              L&apos;agence de référence pour le tourisme temporel de luxe. Membre agréé du
              Consortium Inter-Temporel depuis 2189.
            </p>
          </div>

          <div className="grid grid-cols-2 gap-10 sm:grid-cols-3">
            <div>
              <h3 className="font-mono text-xs uppercase tracking-widest text-foreground">
                Époques
              </h3>
              <ul className="mt-4 space-y-2 text-sm text-muted-foreground">
                <li>Paris 1889</li>
                <li>Le Crétacé</li>
                <li>Florence 1504</li>
              </ul>
            </div>
            <div>
              <h3 className="font-mono text-xs uppercase tracking-widest text-foreground">
                Agence
              </h3>
              <ul className="mt-4 space-y-2 text-sm text-muted-foreground">
                <li>Nos chrono-guides</li>
                <li>Protocole Chronos</li>
                <li>Contact</li>
              </ul>
            </div>
            <div>
              <h3 className="font-mono text-xs uppercase tracking-widest text-foreground">
                Légal
              </h3>
              <ul className="mt-4 space-y-2 text-sm text-muted-foreground">
                <li>Mentions légales</li>
                <li>Conditions de voyage</li>
                <li>Confidentialité temporelle</li>
              </ul>
            </div>
          </div>
        </div>

        <div className="mt-12 rounded-xl border border-accent/30 bg-accent/5 p-5">
          <h3 className="font-heading text-base font-semibold text-foreground">
            Clause de non-responsabilité des paradoxes
          </h3>
          <p className="mt-2 text-xs leading-relaxed text-muted-foreground">
            Chrono-Voyages décline toute responsabilité en cas de paradoxe temporel, d&apos;effet
            papillon, de rencontre avec une version antérieure de soi-même, ou d&apos;altération de
            la ligne temporelle d&apos;origine. Il est formellement interdit de rapporter des objets,
            organismes ou connaissances d&apos;une époque visitée. Le voyageur s&apos;engage à ne pas
            interférer avec les événements historiques majeurs. Toute modification de l&apos;Histoire
            est aux risques et périls — passés, présents et futurs — du voyageur.
          </p>
        </div>

        <div className="mt-10 flex flex-col items-center justify-between gap-4 border-t border-border pt-8 text-xs text-muted-foreground sm:flex-row">
          <p>© 2189 Chrono-Voyages. Tous droits réservés, dans toutes les lignes temporelles.</p>
          <p className="font-mono">Aucun paradoxe n&apos;a été créé pour ce site.</p>
        </div>
      </div>
    </footer>
  )
}
