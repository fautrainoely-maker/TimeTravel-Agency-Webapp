'use client'

import { Button } from '@/components/ui/button'
import { ArrowDown } from 'lucide-react'

function Embers() {
  const embers = Array.from({ length: 18 })
  return (
    <div aria-hidden="true" className="pointer-events-none absolute inset-0 overflow-hidden">
      {embers.map((_, i) => {
        const left = (i * 53) % 100
        const delay = (i % 9) * 0.9
        const duration = 6 + (i % 5)
        const size = 2 + (i % 3)
        return (
          <span
            key={i}
            className="absolute bottom-0 rounded-full bg-primary/70"
            style={{
              left: `${left}%`,
              width: size,
              height: size,
              animation: `ember-rise ${duration}s linear ${delay}s infinite`,
            }}
          />
        )
      })}
    </div>
  )
}

export function Hero() {
  const scrollToDestinations = () =>
    document.querySelector('#destinations')?.scrollIntoView({ behavior: 'smooth' })

  return (
    <section id="top" className="relative isolate flex min-h-screen items-center justify-center overflow-hidden">
      {/* Background "video" — animated zoom on the time portal */}
      <div className="absolute inset-0 -z-10">
        <img
          src="/hero-timeportal.png"
          alt=""
          aria-hidden="true"
          className="h-full w-full object-cover"
          style={{ animation: 'hero-zoom 24s ease-in-out infinite alternate' }}
        />
        <div className="absolute inset-0 bg-background/55" />
        <div className="absolute inset-0 bg-gradient-to-t from-background via-background/40 to-background/70" />
      </div>

      <Embers />

      <div className="mx-auto max-w-4xl px-6 py-32 text-center">
        <p className="mb-6 inline-flex items-center gap-2 rounded-full border border-primary/30 bg-background/40 px-4 py-1.5 font-mono text-xs uppercase tracking-[0.25em] text-primary backdrop-blur-sm">
          Agence de voyage temporel · Est. 2189
        </p>
        <h1 className="font-heading text-5xl font-semibold leading-[1.05] text-balance text-foreground sm:text-7xl lg:text-8xl">
          Le passé n&apos;est plus
          <br />
          <span className="text-primary">hors de portée</span>
        </h1>
        <p className="mx-auto mt-6 max-w-2xl text-pretty text-base leading-relaxed text-muted-foreground sm:text-lg">
          Franchissez le seuil du temps. Dînez sous la Tour Eiffel naissante, marchez parmi
          les dinosaures, croisez les maîtres de la Renaissance. Une seule agence vous y conduit.
        </p>
        <div className="mt-10 flex flex-col items-center justify-center gap-4 sm:flex-row">
          <Button size="lg" className="min-w-44 text-base" onClick={scrollToDestinations}>
            Partir
          </Button>
          <Button
            size="lg"
            variant="outline"
            className="min-w-44 border-primary/40 bg-background/30 text-base backdrop-blur-sm"
            onClick={() => window.dispatchEvent(new CustomEvent('open-chronos'))}
          >
            Parler à Chronos
          </Button>
        </div>
      </div>

      <button
        onClick={scrollToDestinations}
        aria-label="Découvrir les destinations"
        className="absolute bottom-8 left-1/2 -translate-x-1/2 text-muted-foreground transition-colors hover:text-primary"
      >
        <ArrowDown className="size-6 animate-bounce" />
      </button>
    </section>
  )
}
